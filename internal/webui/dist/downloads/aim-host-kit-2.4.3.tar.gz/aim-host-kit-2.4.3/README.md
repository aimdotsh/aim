# AIM host kit（备份/监控协议版本 1）

控制台会通过 SSH 连接目标机的 `aimops` 用户。新版 host kit 同时安装部署执行器，以及在线备份和健康监控所需的协议动作。

```sh
# 解压 host kit 后，在管理电脑执行；--install 会自动在目标机执行一次 sudo 安装
./aim-copy-id --install root@192.168.1.100
```

工具会根据 `uname -m` 选择 amd64/arm64 执行器，生成或复用专用密钥，将公钥、`aim.sh`、引导脚本和执行器复制到目标机，然后创建：

- `aimops` 专用 SSH 账号和受限 `authorized_keys`；
- root-owned `/usr/local/sbin/aim-executor` 和 `/opt/aim/aim.sh`；
- `/var/lib/aim-staging` 以及每个任务独立的暂存目录；
- 仅允许 `aimops` 无密码运行指定执行器的 sudo 规则。

重新执行新版 host kit 是幂等的，不会删除 MySQL 数据。升级控制台或看到 `unsupported action: backup/metrics` 时，必须在每台目标机重新执行一次。

网页“主机资源”中填写：

- SSH 用户：`aimops`；
- 私钥：管理电脑上的 `~/.ssh/aim/aim_console_ed25519` 全文（不要选择同目录的 `.pub` 文件）；
- 首次使用先核对并固定页面显示的 SSH SHA-256 指纹。

备份输出文件归属 `aimops:aimops` 且为 `0600`，控制台下载并校验后会通过 SFTP 删除目标机暂存文件。MySQL root 密码不会写入命令行，也不会打印到任务日志。
